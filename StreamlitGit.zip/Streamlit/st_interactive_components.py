import streamlit as st
import pandas as pd
import numpy as np
from datetime import time,datetime

'''
## Examples of using Interactive Components
---
'''
file_uploader = st.file_uploader("Upload File", type = None,accept_multiple_files = False)

st.write("***-----------------------------------------------------------------------------------***")

button = st.button("Don't Press Me")
if button:
    st.write("都說不要了")
st.write("***-----------------------------------------------------------------------------------***")


checkbox = st.checkbox("Checkbox",value = False) # value here is to choose whether to preselect
if checkbox:
    st.write("こにちは")
st.write("***-----------------------------------------------------------------------------------***")


radio = st.radio("Radio",options = ["opt-1","opt-2"],index = 0, format_func = str)
if radio == 'opt-1':
    st.write("opt-1 selected")
elif radio == 'opt-2':
    st.write("opt-2 selected")
st.write("***-----------------------------------------------------------------------------------***")


selectbox = st.selectbox("SelectBox",options = ["sel-1","sel-2"],index = 0, format_func = str)
if selectbox == 'sel-1':
    st.write("Select-1 has been selected")
elif selectbox == 'sel-2':
    st.write("Select-2 has been selected")
st.write("***-----------------------------------------------------------------------------------***")


multiselect = st.multiselect("MultiSelect",options = ['sel-m1','sel-m2','sel-m3'], default = 'sel-m2')
for x in multiselect:
    st.write(x)
st.write("***-----------------------------------------------------------------------------------***")


age = st.slider('How old are you?',min_value =  0,max_value =  130, step =  25)
st.write("I'm ", age, 'years old')

values = st.slider('Select a range of values',min_value = 0.0, max_value = 100.0, value = (25.0, 75.0))
st.write('Values:', values)

appointment = st.slider("Schedule your appointment:",value=(time(11, 30), time(12, 45)))
st.write("You're scheduled for:", appointment)

start_time = st.slider("When do you start?",value=(datetime(2019, 1, 1, 9, 30),datetime(2020, 1, 1, 9, 30)),
                                                   format="MM/DD/YY - hh:mm")
st.write("Start time:", start_time[0])
st.write("End time:", start_time[1])
st.write("***-----------------------------------------------------------------------------------***")


color = st.select_slider('Select a color of the rainbow',
                         options=['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'])

st.write('My favorite color is', color)

start_color, end_color = st.select_slider('Select a range of color wavelength',
                    options=['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
                                          value=('red', 'blue'))
st.write('You selected wavelengths between: ', start_color, 'and: ', end_color)
st.write("***-----------------------------------------------------------------------------------***")

title = st.text_input("Input Text")
st.write(title)

number = st.number_input("Input Number")
st.write(number)

text_area = st.text_area("Long paragraphs")
st.write(text_area)

date = st.date_input("Input Date")
st.write(date)

time = st.time_input("Input Time")
st.write(time)
st.write("***-----------------------------------------------------------------------------------***")
