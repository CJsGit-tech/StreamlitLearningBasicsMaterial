import streamlit as st
import time

'''
# Basic of Using Cache
'''

import streamlit as st
import time

@st.cache(suppress_st_warning=True)
def expensive_computation(a, b):
    st.write("Cache miss: expensive_computation(", a, ",", b, ") ran")
    time.sleep(2)  # This makes the function take 2s to run
    return {"output": a * b}  # 👈 Mutable object

a = 2
b = 22
res = expensive_computation(a, b)
st.write("Result:", res)
