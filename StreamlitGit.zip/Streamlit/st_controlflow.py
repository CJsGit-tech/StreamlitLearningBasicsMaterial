import streamlit as st
import pandas as pd
import numpy as np

name = st.text_input("Name")
if not name:
    st.warning("Please Input a name")
    st.stop()

st.write(name)
st.success("Thank you for inputting a name")

st.write("***------------------------------------------------------------------------***")

add_selectbox = st.sidebar.selectbox(
    "How would you like to be contacted?",
    ("Email", "Home phone", "Mobile phone")
)
st.write(add_selectbox)

st.write("***------------------------------------------------------------------------***")

with st.beta_container():
    st.write("This is inside the container")
    # You can call any Streamlit command, including custom components:
    st.bar_chart(np.random.randn(50, 3))

st.write("This is outside the container")
st.write("***------------------------------------------------------------------------***")

container = st.beta_container()
container.write("This is inside the container")
st.write("This is outside the container")
# Now insert some more in the container
container.write("This is inside too")

st.write("***------------------------------------------------------------------------***")
col1, col2,col3 = st.beta_columns([5, 2, 2])
data = np.random.randn(10, 1)

col1.subheader("A wide column with a chart")
col1.line_chart(data)

col2.subheader("A narrow column with the data")
col2.write(data)

col3.subheader("A narrow column with the data")
col3.write(data+10)

st.write("***------------------------------------------------------------------------***")

st.line_chart({"data": [1, 5, 2, 6, 2, 1]})

with st.beta_expander("See explanation"):
    st.write("""
    The chart above shows some numbers I picked for you.
    I rolled actual dice for these, so they're *guaranteed* to be random.
    """)

    st.image("https://static.streamlit.io/examples/dice.jpg")

st.write("***------------------------------------------------------------------------***")

import time
my_bar = st.progress(0)

for percent_complete in range(100):
    time.sleep(0.1)
    my_bar.progress(percent_complete + 1)
st.write("Display After Progress Completed")

with st.spinner('Wait for it...'):
    time.sleep(5)
    st.success('Done!')